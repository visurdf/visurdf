var searchData=
[
  ['open',['open',['../classvisu_r_d_f_widget.html#a4cac55fd28ae4160563387a1179d467a',1,'visuRDFWidget']]],
  ['openfile',['openFile',['../class_main_window.html#a288b768c3c21a9171bdc56fe845ece8b',1,'MainWindow']]]
];
